PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  audit_id TEXT PRIMARY KEY,
  run_id TEXT,
  created_at_utc TEXT NOT NULL,
  mode TEXT NOT NULL,
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
  run_id TEXT PRIMARY KEY,
  mode TEXT NOT NULL,
  command TEXT NOT NULL,
  started_at_utc TEXT NOT NULL,
  ended_at_utc TEXT,
  selected_tokens_json TEXT NOT NULL DEFAULT '[]',
  snapshot_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  code_hash_json TEXT NOT NULL DEFAULT '{}',
  config_hash TEXT NOT NULL DEFAULT '',
  manifest_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS signals (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  signal_id TEXT NOT NULL,
  signal_hash TEXT NOT NULL,
  registration_audit_id TEXT NOT NULL,
  created_at_utc TEXT NOT NULL,
  registered_at_utc TEXT NOT NULL,
  city TEXT NOT NULL,
  city_normalized TEXT NOT NULL,
  weather_date_local TEXT NOT NULL,
  weather_metric TEXT NOT NULL,
  temperature_bucket TEXT NOT NULL,
  event_key TEXT NOT NULL,
  market_slug TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  token_id TEXT NOT NULL,
  outcome TEXT NOT NULL,
  side TEXT NOT NULL,
  forecast_temperature TEXT,
  forecast_probability TEXT,
  market_probability_at_signal TEXT,
  intended_usd TEXT NOT NULL,
  max_entry_price TEXT NOT NULL,
  entry_deadline_utc TEXT NOT NULL,
  source TEXT NOT NULL,
  notes TEXT,
  mode TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_signals_mode_signal_hash ON signals(mode, signal_id, signal_hash);

CREATE TABLE IF NOT EXISTS entry_order_state (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  signal_id TEXT NOT NULL,
  token_id TEXT NOT NULL,
  updated_at_utc TEXT NOT NULL,
  intended_usd TEXT NOT NULL,
  filled_entry_usd TEXT NOT NULL,
  remaining_entry_usd TEXT NOT NULL,
  filled_entry_shares TEXT NOT NULL,
  entry_status TEXT NOT NULL,
  max_entry_price TEXT NOT NULL,
  entry_deadline_utc TEXT NOT NULL,
  last_entry_attempt_at TEXT,
  last_attempt_reason TEXT,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS token_validations (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  market_slug TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  token_id TEXT NOT NULL,
  outcome TEXT NOT NULL,
  event_key TEXT NOT NULL,
  mapping_valid INTEGER NOT NULL,
  error_message TEXT NOT NULL,
  raw_gamma_market_hash TEXT NOT NULL,
  raw_clob_market_hash TEXT NOT NULL,
  raw_orderbook_hash TEXT,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fee_validations (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  market_slug TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  fees_enabled INTEGER,
  clob_fee_rate TEXT,
  clob_fee_exponent TEXT,
  clob_taker_only TEXT,
  clob_fee_effective_from TEXT,
  gamma_fee_schedule TEXT NOT NULL,
  gamma_fee_rate TEXT,
  fee_crosscheck_status TEXT NOT NULL,
  fee_conflict_details TEXT NOT NULL,
  raw_clob_market_hash TEXT NOT NULL,
  raw_gamma_market_hash TEXT NOT NULL,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orderbook_snapshots (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  captured_at_utc TEXT NOT NULL,
  token_id TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  market_slug TEXT NOT NULL,
  purpose TEXT NOT NULL,
  best_bid TEXT,
  best_ask TEXT,
  spread TEXT,
  tick_size TEXT NOT NULL,
  min_order_size TEXT NOT NULL,
  neg_risk INTEGER,
  raw_orderbook_json TEXT NOT NULL,
  source_endpoint TEXT NOT NULL,
  mode TEXT NOT NULL,
  UNIQUE(run_id, snapshot_id)
);

CREATE TABLE IF NOT EXISTS entry_fills (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_fill_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  filled_at_utc TEXT NOT NULL,
  gross_entry_cost TEXT NOT NULL,
  entry_fee TEXT NOT NULL,
  net_entry_cost TEXT NOT NULL,
  filled_shares TEXT NOT NULL,
  entry_vwap TEXT NOT NULL,
  fee_status TEXT NOT NULL,
  best_bid TEXT,
  best_ask TEXT,
  spread TEXT,
  complete_fill INTEGER NOT NULL,
  unfilled_usd_after_fill TEXT NOT NULL,
  depth_levels_json TEXT NOT NULL,
  mode TEXT NOT NULL,
  UNIQUE(run_id, signal_id, snapshot_id)
);

CREATE TABLE IF NOT EXISTS strategy_lots (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  lot_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  entry_fill_id TEXT NOT NULL,
  created_at_utc TEXT NOT NULL,
  entry_shares TEXT NOT NULL,
  gross_entry_cost TEXT NOT NULL,
  entry_fee TEXT NOT NULL,
  net_entry_cost TEXT NOT NULL,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS strategy_triggers (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  trigger_id TEXT NOT NULL,
  run_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  trigger_stage_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  trigger_created_at TEXT NOT NULL,
  trigger_target_shares TEXT NOT NULL,
  trigger_filled_shares TEXT NOT NULL,
  trigger_remaining_shares TEXT NOT NULL,
  trigger_status TEXT NOT NULL,
  trigger_completed_at TEXT,
  rolling_avg_cost_at_trigger TEXT NOT NULL,
  threshold_price TEXT NOT NULL,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS exit_fills (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  exit_fill_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  trigger_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  trigger_stage_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  filled_at_utc TEXT NOT NULL,
  planned_sell_shares TEXT NOT NULL,
  filled_shares TEXT NOT NULL,
  gross_exit_proceeds TEXT NOT NULL,
  exit_fee TEXT NOT NULL,
  net_exit_proceeds TEXT NOT NULL,
  exit_vwap TEXT NOT NULL,
  fee_status TEXT NOT NULL,
  best_bid TEXT,
  best_ask TEXT,
  spread TEXT,
  complete_fill INTEGER NOT NULL,
  unfilled_trigger_shares_after_fill TEXT NOT NULL,
  depth_levels_json TEXT NOT NULL,
  mode TEXT NOT NULL,
  UNIQUE(run_id, trigger_id, snapshot_id)
);

CREATE TABLE IF NOT EXISTS exit_fill_allocations (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  allocation_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  exit_fill_id TEXT NOT NULL,
  trigger_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  lot_id TEXT NOT NULL,
  allocated_shares TEXT NOT NULL,
  gross_exit_proceeds TEXT NOT NULL,
  exit_fee TEXT NOT NULL,
  net_exit_proceeds TEXT NOT NULL,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settlements (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  settlement_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  token_id TEXT NOT NULL,
  source_endpoint TEXT NOT NULL,
  source_reference TEXT NOT NULL,
  observed_at_utc TEXT NOT NULL,
  recorded_at_utc TEXT NOT NULL,
  raw_response TEXT NOT NULL,
  raw_response_hash TEXT NOT NULL,
  market_status TEXT NOT NULL,
  resolution_status TEXT NOT NULL,
  winning_asset_id TEXT,
  winning_outcome TEXT,
  token_settlement_values TEXT NOT NULL,
  evidence_valid INTEGER NOT NULL,
  settlement_value TEXT NOT NULL,
  remaining_shares_settled TEXT NOT NULL,
  gross_settlement_proceeds TEXT NOT NULL,
  settlement_fee TEXT NOT NULL,
  net_settlement_proceeds TEXT NOT NULL,
  fee_status TEXT NOT NULL,
  mode TEXT NOT NULL,
  UNIQUE(signal_id, strategy_id, mode)
);

CREATE TABLE IF NOT EXISTS settlement_allocations (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  settlement_allocation_id TEXT NOT NULL UNIQUE,
  run_id TEXT NOT NULL,
  settlement_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  token_id TEXT NOT NULL,
  lot_id TEXT NOT NULL,
  settled_shares TEXT NOT NULL,
  gross_settlement_proceeds TEXT NOT NULL,
  settlement_fee TEXT NOT NULL,
  net_settlement_proceeds TEXT NOT NULL,
  mode TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_results (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  signal_count INTEGER NOT NULL,
  position_count INTEGER NOT NULL,
  traded_event_count INTEGER NOT NULL,
  settled_event_count INTEGER NOT NULL,
  gross_entry_cost TEXT NOT NULL,
  entry_fee TEXT NOT NULL,
  gross_exit_proceeds TEXT NOT NULL,
  exit_fee TEXT NOT NULL,
  gross_settlement_proceeds TEXT NOT NULL,
  settlement_fee TEXT NOT NULL,
  total_fees TEXT NOT NULL,
  gross_pnl TEXT,
  net_pnl TEXT,
  triggered_take_profit INTEGER NOT NULL,
  incomplete_take_profit INTEGER NOT NULL
);
